const SkillsText = () => {
  return (
    <div className="flex flex-col items-center mt-[100px]">
      <h2 className="text-6xl text-cyan mb-10">Mes competences</h2>
      <p className="text-lg text-center">
      Dans le domaine des réseaux informatiques, je maîtrise la conception, la configuration et la gestion d’infrastructures réseau adaptées aux besoins des entreprises. Grâce à mon expertise en protocoles réseau, en sécurité et en administration des équipements, je suis capable de mettre en place des solutions performantes et évolutives. Mon expérience inclut la configuration de services essentiels (DHCP, DNS, VLAN, MPLS), le câblage structuré, ainsi que l’optimisation et la sécurisation des flux de communication.
      </p>
    </div>
  );
};

export default SkillsText;
