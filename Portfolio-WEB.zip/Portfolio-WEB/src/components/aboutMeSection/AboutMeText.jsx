import { Link } from "react-scroll";

const AboutMeText = () => {
  return (
    <div className="flex flex-col md:items-start sm:items-center md:text-left sm:text-center">
      <h2 className="text-6xl text-cyan mb-10">A Propos de moi</h2>
      <p>
        Je suis NZILA NGALA Amour Samuel, Passionné par les technologies réseau, j’ai acquis des compétences solides en administration et configuration de réseaux informatiques, notamment dans le cadre du CCNA. Mon expérience couvre la mise en place et la gestion de réseaux d’entreprise, l’implémentation de protocoles essentiels, ainsi que le déploiement de solutions adaptées aux besoins des infrastructures modernes.
      </p>
      <button className="border border-orange rounded-full py-2 px-4 text-lg flex gap-2 items-center mt-10 hover:bg-orange transition-all duration-500 cursor-pointer md:self-start sm:self-center">
        <Link
          spy={true}
          smooth={true}
          duration={500}
          offset={-120}
          to="projects"
          className="cursor-pointer text-white hover:text-cyan transition-all duration-500"
        >
          Mes Projets
        </Link>
      </button>
    </div>
  );
};

export default AboutMeText;
