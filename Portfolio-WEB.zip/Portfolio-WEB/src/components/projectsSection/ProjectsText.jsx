const ProjectsText = () => {
  return (
    <div className="flex flex-col items-center mt-[100px]">
      <h2 className="text-6xl text-cyan mb-10">Projects</h2>
      <p className="text-lg text-center">
      J’ai travaillé sur une variété de projets en réseaux informatiques, allant de la mise en place de réseaux pour petites entreprises à l’administration d’infrastructures complexes intégrant des protocoles avancés et des solutions de sécurité.
      </p>
    </div>
  );
};

export default ProjectsText;
