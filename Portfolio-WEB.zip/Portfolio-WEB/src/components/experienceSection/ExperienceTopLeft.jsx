import ExperienceInfo from "./ExperienceInfo";

const ExperienceTopLeft = () => {
  return (
    <div className="flex flex-col gap-6 w-[300px]">
      <p className="text-orange font-bold uppercase text-3xl font-special text-center">
        Depuis 2022
      </p>
      <div className="flex justify-center items-center gap-4">
        <ExperienceInfo number="3" text="Ans" />
        <p className="font-bold text-6xl text-lightBrown">-</p>
        <ExperienceInfo number="10" text="Projets en réseaux" />
      </div>
      <p className="text-center">
        Avec 3 ans d’expérience dans la création d’applications web dynamiques et conviviales.
      </p>
      <ExperienceInfo number="12 000 000 FCFA" text="Max Budget" />
    </div>
  );
};

export default ExperienceTopLeft;
