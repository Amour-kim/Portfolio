const ExperienceTopRight = () => {
  return (
    <div className="xl:w-[25%] lg:w-[30%] border border-lightBrown p-4 rounded-xl">
      <p className="text-lg text-center text-lightGrey">
      Je me spécialise dans{" "}
        <span className="font-bold text-white">
        l’administration et la configuration des réseaux informatiques
        </span>
        , en appliquant les meilleures pratiques pour concevoir des infrastructures performantes, sécurisées et évolutives. <br />
        Mon expérience couvre divers projets, allant de la mise en place de réseaux pour petites entreprises à des architectures{" "}
        <span className="font-bold text-white">plus complexes intégrant VLAN, MPLS et routage avancé</span>,
        Je veille toujours à optimiser la connectivité, la sécurité et la fiabilité des systèmes pour garantir un réseau efficace et adapté aux besoins des utilisateurs.
      </p>
    </div>
  );
};

export default ExperienceTopRight;
