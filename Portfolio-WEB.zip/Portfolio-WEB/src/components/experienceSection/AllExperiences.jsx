import SingleExperience from "./SingleExperience";
import { FaArrowRightLong } from "react-icons/fa6";
import { motion } from "framer-motion";
import { fadeIn } from "../../framerMotion/variants";

const experiences = [
  {
    job: "Gestion et configuration des infrastructures réseau",
    company: "IOI",
    date: "2022 - Present",
    responsibilities: [
      "Configuration et maintenance des équipements réseau.",
      "Mise en place des protocoles DHCP, DNS, VLAN et MPLS",
      "Surveillance et analyse du trafic avec Wireshark",
    ],
  },
  {
    job: "Conception et déploiement de Topologies",
    company: "UNG",
    date: "2023 - Present",
    responsibilities: [
      "Élaboration de schémas réseau pour différents départements",
      "Segmentation du réseau avec VLAN et routage inter-VLAN",
      "Optimisation du réseau pour assurer une connectivité fluide",
    ],
  },
  {
    job: "Sécurisation et supervision des réseaux",
    company: "Artix",
    date: "2023 - 2024",
    responsibilities: [
      "Implémentation des règles de sécurité avec des pare-feu et ACL",
      "Surveillance des logs et détection d’anomalies réseau",
      "Configuration et gestion des VPN pour l’accès distant sécurisé",
    ],
  },
];

const AllExperiences = () => {
  return (
    <div className="flex md:flex-row sm:flex-col items-center justify-between">
      {experiences.map((experience, index) => {
        return (
          <>
            <SingleExperience key={index} experience={experience} />
            {index < 2 ? (
              <motion.div
                variants={fadeIn("right", 0)}
                initial="hidden"
                whileInView="show"
                viewport={{ once: false, amount: 0.7 }}
              >
                <FaArrowRightLong className="text-6xl text-orange lg:block sm:hidden" />
              </motion.div>
            ) : (
              ""
            )}
          </>
        );
      })}
    </div>
  );
};

export default AllExperiences;
