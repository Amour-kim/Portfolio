const ContactText = () => {
  return (
    <div>
      <h2 className="text-orange text-3xl mb-4">Contactez-moi</h2>
      <p>
        N'hésitez pas à me contacter si vous souhaitez collaborer.
        <br />
        Vous n’êtes qu’à quelques clics !
      </p>
    </div>
  );
};

export default ContactText;
